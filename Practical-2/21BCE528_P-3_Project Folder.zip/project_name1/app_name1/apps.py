from django.apps import AppConfig


class AppName1Config(AppConfig):
    name = 'app_name1'
