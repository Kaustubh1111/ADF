from django.contrib import admin
from .models import suser
# Register your models here.
admin.site.register(suser)