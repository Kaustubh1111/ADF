from django.shortcuts import render
from .models import suser as user
from django.contrib import messages
# Create your views here.
from django.utils.datastructures import MultiValueDictKeyError


def register(req):

    try:
        is_private = req.POST['fname']
    except MultiValueDictKeyError:
        is_private = False

    if req.method == 'POST':
        fname = req.POST['fname']
        lname = req.POST['lname']
        uname = req.POST['uname']
        email = req.POST['email']
        password = req.POST['password']

        f = 0
        user = user.objects.all()
        for u in user:
            if u.uname == uname:
                f=1
                messages.info(req,"Username is already taken.")
                break
            if u.email == email:
                f=1
                messages.info(req,"Username is already taken.")
                break
        
        if f == 0:
            user(fname=fname,lname=lname,uname=uname,email=email,password=password).save()
            messages.info(req,"hello, " + req.POST['uname'])
            req.session['uname'] = uname
            return render(req,'index.html')
        else:
            return render(req, 'register.html')
    else:
        return render(req, 'register.html')
    
def login(req):
    if req.method == 'POST':
        try:
            userdetails = user.objects.get(uname = req.POST['uname'],email = req.POST['email'], password = req.POST['password'])
            req.session['uname'] = userdetails.uname
            return render(req, 'index.html')
        except user.DoesNotExist as e:
            messages.info(req, "Email/ password does not match..")
    return render(req, 'login.html')

def logout(req):
    try:
        del req.session['uname']
    except:
        return render(req,'index.html')
    return render(req, 'login.html')
    