from django.contrib import admin
from .models import JobPosting
# Register your models here.

admin.site.register(JobPosting)